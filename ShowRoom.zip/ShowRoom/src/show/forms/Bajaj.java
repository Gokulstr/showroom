package show.forms;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;
import show.img.*;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

public class Bajaj extends JFrame{

	//private JFrame frame;
	private JTextField t1;
	private JPasswordField t2;
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bajaj window = new Bajaj();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Bajaj() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//getContentPane().setLayout(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		Image i=Toolkit.getDefaultToolkit().getImage("index.png");
		setIconImage(i);
		//setIconImage(new ImageIcon("index.png").getImage());
		/*try {
			setIconImage(ImageIO.read(new FileInputStream("adds/index.png")));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		JLabel lblGokulBajajLogin = new JLabel("Gokul Bajaj Login");
		lblGokulBajajLogin.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblGokulBajajLogin.setBounds(131, 11, 200, 38);
		contentPane.add(lblGokulBajajLogin);
		
		JLabel lblEnterTheUsername = new JLabel("Enter the username");
		lblEnterTheUsername.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEnterTheUsername.setBounds(28, 60, 155, 50);
		contentPane.add(lblEnterTheUsername);
		
		JLabel lblEnterThePassword = new JLabel("Enter the password");
		lblEnterThePassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEnterThePassword.setBounds(28, 122, 155, 50);
		contentPane.add(lblEnterThePassword);
		
		t1 = new JTextField();
		t1.setBounds(200, 72, 166, 20);
		contentPane.add(t1);
		t1.setColumns(10);
		
		t2 = new JPasswordField();
		t2.setEchoChar('B');
		t2.setBounds(200, 139, 166, 20);
		contentPane.add(t2);
		
		JButton btnLogin = new JButton("LogIn");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(t1.getText().equals("gokul")&&t2.getText().equals("salem"))
				{
					GokulBajaj gb=new GokulBajaj();
					gb.setVisible(true);
					Bajaj.this.dispose();
				}
			}
		});
		btnLogin.setBounds(95, 202, 89, 23);
		contentPane.add(btnLogin);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(234, 202, 89, 23);
		contentPane.add(btnCancel);
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(contentPane);
	}
}
