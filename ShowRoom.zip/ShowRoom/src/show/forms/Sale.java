package show.forms;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import show.middle.ReportException;
import show.middle.Sales;
import show.middle.Vehicle;
import show.middle.VehicleException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class Sale extends JFrame implements ItemListener 
{

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private JTextField t6;
	private JTextField t7;
	private JComboBox t2;
	private String query, driver="com.mysql.jdbc.Driver",location="jdbc:mysql://localhost:3306/showroom";
	private Connection con;
	private PreparedStatement pState;
	private Object[] bikes;
	private JTextField t8;
	private Vector<Vehicle> two;
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sale frame = new Sale();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public Sale() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 785, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		Image i=Toolkit.getDefaultToolkit().getImage("index.png");
		setIconImage(i);
		
		JLabel lblBajajSales = new JLabel("Bajaj Sales");
		lblBajajSales.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBajajSales.setBounds(305, 11, 150, 22);
		contentPane.add(lblBajajSales);
		
		t1 = new JTextField();
		t1.setToolTipText("Enter the Date in the form of dd/mm/yyyy");
		t1.setBounds(283, 44, 162, 20);
		contentPane.add(t1);
		t1.setColumns(10);
		// fetch modelNames from vehicle table which quantity >0
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(location,"root","");
			query="select * from vehicle where quantity > 0";
			pState=con.prepareStatement(query);
			ResultSet status=pState.executeQuery();
			Vector<String> temp=new Vector<String>();
			two=new Vector<Vehicle>();
			Vehicle v;
			while(status.next())
			{
				v=new Vehicle();
				v.setModelName(status.getString("modelName"));
				v.setType(status.getString("type"));
				v.setModelYear(status.getInt("modelYear"));
				v.setEngineCapacity(status.getInt("engineCapacity"));
				v.setAverageMilage(status.getInt("averageMilage"));
				v.setQuantity(status.getInt("quantity"));
				v.setWarrenty(status.getInt("warrenty"));
				v.setOnRoadPrice(status.getDouble("onRoadPrice"));
				two.add(v);
				temp.add(status.getString("modelName"));
			}
			bikes=temp.toArray();// feed fetched modelnames from table
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t2 = new JComboBox(bikes);
		t2.setBounds(176, 94, 162, 20);
		contentPane.add(t2);
		t2.addItemListener(this);
		
		t3 = new JTextField();
		t3.setToolTipText("Consumer Name");
		t3.setColumns(10);
		t3.setBounds(283, 143, 162, 20);
		contentPane.add(t3);
		
		t4 = new JTextField();
		t4.setToolTipText("Consumer Address");
		t4.setColumns(10);
		t4.setBounds(283, 196, 162, 20);
		contentPane.add(t4);
		
		t5 = new JTextField();
		t5.setToolTipText("Payment Mode");
		t5.setColumns(10);
		t5.setBounds(283, 246, 162, 20);
		contentPane.add(t5);
		
		t6 = new JTextField();
		t6.setToolTipText("Mobile Number");
		t6.setColumns(10);
		t6.setBounds(283, 296, 162, 20);
		contentPane.add(t6);
		
		t7 = new JTextField();
		t7.setToolTipText("Paid Amount");
		t7.setColumns(10);
		t7.setBounds(283, 341, 162, 20);
		contentPane.add(t7);
		
		t8 = new JTextField();
		t8.setEditable(false);
		t8.setBounds(401, 94, 150, 20);
		contentPane.add(t8);
		t8.setColumns(10);
		
		JButton b1 = new JButton("Sale");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Sales s=new Sales();
				s.setDate(t1.getText());
				s.setModelName(t2.getSelectedItem().toString());s.setOnRoadPrice(Double.parseDouble(t8.getText()));
				s.setConsumerName(t3.getText());s.setAddress(t4.getText());
				s.setPaymentMode(t5.getText());s.setMobileNumber(Long.parseLong(t6.getText()));
				s.setPaid(Integer.parseInt(t7.getText()));
				// insert new bill in sales table
				try {
					Class.forName(driver);
					con=DriverManager.getConnection(location,"root","");
					query="insert into sales(date,modelName,onRoadPrice,consumerName,address,paymentMode,mobileNumber,paid) values(?,?,?,?,?,?,?,?)";
					pState=con.prepareStatement(query);
					pState.setString(1, s.getDate());pState.setString(2, s.getModelName());
					pState.setDouble(3, s.getOnRoadPrice());
					pState.setString(4, s.getConsumerName());pState.setString(5, s.getAddress());
					pState.setString(6, s.getPaymentMode());pState.setLong(7,s.getMobileNumber());
					pState.setInt(8, s.getPaid());
					int status=pState.executeUpdate();
					if(status!=0)
					{
						// get inserted bill invoice number
						Class.forName(driver);
						con=DriverManager.getConnection(location,"root","");
						query="select invoiceNumber from sales where modelName=? and consumerName=?";
						PreparedStatement pState=con.prepareStatement(query);
						pState.setString(1, s.getModelName());
						pState.setString(2, s.getConsumerName());
						ResultSet stat=pState.executeQuery();
						if(stat.next())
						{
							JOptionPane.showMessageDialog(Sale.this, "Bill number is: "+stat.getInt("invoiceNumber"));
							// update vehicle count
							int q=0;
							for(Vehicle n:two)
							{
								if(n.getModelName().equals(s.getModelName()))
								{
									q=n.getQuantity();
								}
							}
							Class.forName(driver);
							con=DriverManager.getConnection(location,"root","");
							query="update vehicle set quantity = ? where modelName = ?";
							pState=con.prepareStatement(query);
							q--;
							pState.setInt(1, q);
							pState.setString(2, s.getModelName());
							int result=pState.executeUpdate();
							if(result!=0)
							{
								JOptionPane.showMessageDialog(Sale.this, "Stock Updated");
							}
							else
							{
								throw new VehicleException(" cannot updated");
							}
						}
						else
						{
							throw new ReportException();
						}
					}
					else
					{
						throw new ReportException();
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch(ReportException x)
				{
					JOptionPane.showMessageDialog(Sale.this, x);
				}
				catch(VehicleException x)
				{
					JOptionPane.showMessageDialog(Sale.this, x);
				}
			}
		});
		b1.setBounds(176, 377, 89, 23);
		contentPane.add(b1);
		
		JButton b2 = new JButton("Clear");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				t1.setText("");t3.setText("");
				t4.setText("");t5.setText("");
				t6.setText("");t7.setText("");
			}
		});
		b2.setBounds(462, 377, 89, 23);
		contentPane.add(b2);
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(contentPane);
	}

	// update onroad price depends on modelName
	@Override
	public void itemStateChanged(ItemEvent arg0) 
	{
		String j=t2.getSelectedItem().toString();
		for(Vehicle b:two)
		{
			if(b.getModelName().equals(j))
			{
				t8.setText(b.getOnRoadPrice().toString());
			}
		}
	}
}
