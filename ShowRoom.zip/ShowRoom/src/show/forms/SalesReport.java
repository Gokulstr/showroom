package show.forms;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import show.middle.ReportException;
import show.middle.Sales;
import show.middle.VehicleException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SalesReport extends JFrame {

	private JPanel contentPane;
	private JTextField d1;
	private JTextField d2;
	private JTable table;
	private Vector<String> title,cont;
	private Vector<Vector> rows;
	private Vector<Sales> rep;
	private JScrollPane scrollPane;
	private JLabel tot;
	private double total=0.0;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalesReport frame = new SalesReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public SalesReport() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 781, 448);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		Image i=Toolkit.getDefaultToolkit().getImage("index.png");
		setIconImage(i);
		
		JLabel lblBajajSalesReport = new JLabel("Bajaj Sales Report");
		lblBajajSalesReport.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBajajSalesReport.setBounds(278, 11, 200, 22);
		contentPane.add(lblBajajSalesReport);
		
		d1 = new JTextField();
		d1.setToolTipText("Enter the from date");
		d1.setBounds(173, 52, 86, 20);
		contentPane.add(d1);
		d1.setColumns(10);
		
		d2 = new JTextField();
		d2.setToolTipText("Enter the to date");
		d2.setColumns(10);
		d2.setBounds(424, 52, 86, 20);
		contentPane.add(d2);
		
		JLabel lblFromDate = new JLabel("From Date:");
		lblFromDate.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFromDate.setBounds(52, 55, 86, 17);
		contentPane.add(lblFromDate);
		
		JLabel lblToDate = new JLabel("To Date:");
		lblToDate.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblToDate.setBounds(324, 52, 86, 17);
		contentPane.add(lblToDate);
		
		
		JLabel lblHereIsThe = new JLabel("Here is the Report");
		lblHereIsThe.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblHereIsThe.setBounds(52, 108, 158, 17);
		contentPane.add(lblHereIsThe);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 135, 745, 264);
		contentPane.add(scrollPane);
		
		tot = new JLabel("Total Sales is: ");
		tot.setFont(new Font("Tahoma", Font.BOLD, 14));
		tot.setBounds(324, 108, 260, 17);
		contentPane.add(tot);
		
		JButton btnGenerateReport = new JButton("Generate Report");
		btnGenerateReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				rep=new Vector<Sales>();
				LocalDate date1=LocalDate.parse(d1.getText(),DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				LocalDate date2=LocalDate.parse(d2.getText(),DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/showroom","root","");
					String qry="select * from sales where date between ? and ?";
					PreparedStatement pState=con.prepareStatement(qry);
					pState.setString(1, date1.toString());
					pState.setString(2, date2.toString());
					ResultSet status=pState.executeQuery();
					Sales s;
					if(status.next())
					{
						s=new Sales();
						s.setInvoiceNumber(status.getInt("invoiceNumber"));
						s.setDate(LocalDate.parse(status.getString("date")));
						s.setModelName(status.getString("modelName"));
						s.setOnRoadPrice(status.getDouble("onRoadPrice"));
						s.setConsumerName(status.getString("consumerName"));
						s.setAddress(status.getString("address"));
						s.setPaymentMode(status.getString("paymentMode"));
						s.setMobileNumber(status.getLong("mobileNumber"));
						total+=status.getInt("paid");
						s.setPaid(status.getInt("paid"));
						rep.add(s);
						while(status.next())
						{
							s=new Sales();
							s.setInvoiceNumber(status.getInt("invoiceNumber"));
							s.setDate(LocalDate.parse(status.getString("date")));
							s.setModelName(status.getString("modelName"));
							s.setOnRoadPrice(status.getDouble("onRoadPrice"));
							s.setConsumerName(status.getString("consumerName"));
							s.setAddress(status.getString("address"));
							s.setPaymentMode(status.getString("paymentMode"));
							s.setMobileNumber(status.getLong("mobileNumber"));
							total+=status.getInt("paid");
							s.setPaid(status.getInt("paid"));
							System.out.println(s);
							rep.add(s);
						}
					}
					else
					{
						throw new ReportException();
					}
					title=new Vector<String>();title.add("InVoice No");
					title.add("Bill Date");title.add("Model Name");
					title.add("Price");title.add("Consumer Name");
					title.add("Address");title.add("Contact");
					title.add("Paid mode");title.add("Paid");
					rows=new Vector<Vector>();
					//rows.add(title);
					for(Sales x:rep)
					{
						cont=new Vector<String>();
						cont.add(x.getInvoiceNumber().toString());
						cont.add(x.getDate());
						cont.add(x.getModelName());
						cont.add(x.getOnRoadPrice().toString());
						cont.add(x.getConsumerName());
						cont.add(x.getAddress());
						cont.add(x.getMobileNumber().toString());
						cont.add(x.getPaymentMode());
						cont.add(x.getPaid().toString());
						rows.add(cont);
					}
					table = new JTable(rows,title);
					//JTableHeader
					scrollPane.setViewportView(table);
					tot.setText("Total: "+total);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch(ReportException x)
				{
					JOptionPane.showMessageDialog(SalesReport.this, x);
				}
				
			}
		});
		
		btnGenerateReport.setBounds(585, 51, 129, 23);
		contentPane.add(btnGenerateReport);
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(contentPane);
	}
}
