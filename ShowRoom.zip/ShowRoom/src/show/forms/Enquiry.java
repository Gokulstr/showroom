package show.forms;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import show.middle.VehicleException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Enquiry extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	private JLabel lblModelName;
	private JLabel lblModelType;
	private JLabel lblModelYear;
	private JLabel lblEngineCapacity;
	private JLabel lblMilageYouCan;
	private JLabel lblNoOfStocks;
	private JLabel lblWarrenty;
	private JLabel lblOnRoadPrice;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Enquiry frame = new Enquiry();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public Enquiry() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 785, 446);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		Image i=Toolkit.getDefaultToolkit().getImage("index.png");
		setIconImage(i);
		
		JLabel lblBajajConsumerEnquiry = new JLabel("Bajaj Consumer Enquiry");
		lblBajajConsumerEnquiry.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBajajConsumerEnquiry.setBounds(273, 11, 242, 28);
		contentPane.add(lblBajajConsumerEnquiry);
		
		JLabel lblTellUsYour = new JLabel("Tell us your desired Model Name");
		lblTellUsYour.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblTellUsYour.setBounds(105, 62, 234, 28);
		contentPane.add(lblTellUsYour);
		
		t1 = new JTextField();
		t1.setToolTipText("Enter the Model Name");
		t1.setBounds(400, 68, 119, 20);
		contentPane.add(t1);
		t1.setColumns(10);
		
		
		JLabel lblHereIsYour = new JLabel("Here is Your Desired bike Details");
		lblHereIsYour.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblHereIsYour.setBounds(105, 114, 234, 20);
		contentPane.add(lblHereIsYour);
		
		l1 = new JLabel("");
		l1.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l1.setBounds(400, 147, 163, 20);
		contentPane.add(l1);
		
		l2 = new JLabel("");
		l2.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l2.setBounds(400, 178, 163, 20);
		contentPane.add(l2);
		
		l3 = new JLabel("");
		l3.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l3.setBounds(400, 211, 163, 20);
		contentPane.add(l3);
		
		l4 = new JLabel("");
		l4.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l4.setBounds(400, 244, 163, 20);
		contentPane.add(l4);
		
		l5 = new JLabel("");
		l5.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l5.setBounds(400, 278, 163, 20);
		contentPane.add(l5);
		
		l6 = new JLabel("");
		l6.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l6.setBounds(400, 310, 163, 20);
		contentPane.add(l6);
		
		l7 = new JLabel("");
		l7.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l7.setBounds(400, 344, 163, 20);
		contentPane.add(l7);
		
		l8 = new JLabel("");
		l8.setFont(new Font("Tahoma", Font.ITALIC, 14));
		l8.setBounds(400, 377, 163, 20);
		contentPane.add(l8);
		
		JButton b1 = new JButton("ShowDetails");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String a=t1.getText();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/showroom","root","");
					String qry="select * from vehicle where modelName=?";
					PreparedStatement pState=con.prepareStatement(qry);
					pState.setString(1, a);
					ResultSet status=pState.executeQuery();
					if(status.next())
					{
						JOptionPane.showMessageDialog(Enquiry.this, "Vehicle Details will be shown here");
						l1.setText(status.getString("modelName"));l2.setText(status.getString("type"));
						l3.setText(status.getString("modelYear"));l4.setText(status.getString("engineCapacity"));
						l5.setText(status.getString("averageMilage"));l6.setText(status.getString("quantity"));
						l7.setText(status.getString("warrenty"));l8.setText(status.getString("onRoadPrice"));
						t1.setText("");
					}
					else
					{
						throw new VehicleException();
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch(VehicleException x)
				{
					JOptionPane.showMessageDialog(Enquiry.this, x);
				}
			}
		});
		b1.setBounds(563, 67, 119, 23);
		contentPane.add(b1);
		
		lblModelName = new JLabel("Model Name");
		lblModelName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblModelName.setBounds(105, 145, 141, 22);
		contentPane.add(lblModelName);
		
		lblModelType = new JLabel("Model Type");
		lblModelType.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblModelType.setBounds(105, 176, 141, 22);
		contentPane.add(lblModelType);
		
		lblModelYear = new JLabel("Model Year");
		lblModelYear.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblModelYear.setBounds(105, 209, 141, 22);
		contentPane.add(lblModelYear);
		
		lblEngineCapacity = new JLabel("Engine Capacity");
		lblEngineCapacity.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEngineCapacity.setBounds(105, 242, 141, 22);
		contentPane.add(lblEngineCapacity);
		
		lblMilageYouCan = new JLabel("Milage you can expect");
		lblMilageYouCan.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMilageYouCan.setBounds(105, 276, 163, 22);
		contentPane.add(lblMilageYouCan);
		
		lblNoOfStocks = new JLabel("No of Stocks");
		lblNoOfStocks.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNoOfStocks.setBounds(105, 308, 141, 22);
		contentPane.add(lblNoOfStocks);
		
		lblWarrenty = new JLabel("Warrenty");
		lblWarrenty.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblWarrenty.setBounds(105, 342, 141, 22);
		contentPane.add(lblWarrenty);
		
		lblOnRoadPrice = new JLabel("On Road Price");
		lblOnRoadPrice.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblOnRoadPrice.setBounds(105, 375, 141, 22);
		contentPane.add(lblOnRoadPrice);
		
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(contentPane);
		
	}
}
