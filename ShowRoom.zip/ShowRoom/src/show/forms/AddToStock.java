package show.forms;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import show.middle.Vehicle;
import show.middle.VehicleException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddToStock extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t3;
	private JTextField t5;
	private JTextField t6;
	private JTextField t9;
	private JTextField t2;
	private JTextField t4;
	private JTextField t7;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddToStock frame = new AddToStock();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public AddToStock() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 793, 464);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		Image i=Toolkit.getDefaultToolkit().getImage("index.png");
		setIconImage(i);
		
		JLabel lblBajajStockAdd = new JLabel("Bajaj Stock Add");
		lblBajajStockAdd.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblBajajStockAdd.setBounds(293, 11, 191, 22);
		contentPane.add(lblBajajStockAdd);
		
		t1 = new JTextField();
		t1.setToolTipText("Enter the Model name");
		t1.setBounds(293, 60, 133, 20);
		contentPane.add(t1);
		t1.setColumns(10);
		
		t3 = new JTextField();
		t3.setToolTipText("Enter the Model year");
		t3.setColumns(10);
		t3.setBounds(293, 122, 133, 20);
		contentPane.add(t3);
		
		t5 = new JTextField();
		t5.setToolTipText("Enter the Milage");
		t5.setColumns(10);
		t5.setBounds(293, 184, 133, 20);
		contentPane.add(t5);
		
		t6 = new JTextField();
		t6.setToolTipText("Enter the quantity");
		t6.setColumns(10);
		t6.setBounds(293, 215, 133, 20);
		contentPane.add(t6);
		
		t9 = new JTextField();
		t9.setToolTipText("Enter the Price");
		t9.setColumns(10);
		t9.setBounds(293, 277, 133, 20);
		contentPane.add(t9);
		
		t2 = new JTextField();
		t2.setToolTipText("Enter the Model Type");
		t2.setColumns(10);
		t2.setBounds(293, 91, 133, 20);
		contentPane.add(t2);
		
		t4 = new JTextField();
		t4.setToolTipText("Enter the engine capacity");
		t4.setColumns(10);
		t4.setBounds(293, 153, 133, 20);
		contentPane.add(t4);
		
		t7 = new JTextField();
		t7.setToolTipText("Enter the warrenty");
		t7.setColumns(10);
		t7.setBounds(293, 246, 133, 20);
		contentPane.add(t7);
		
		JButton b1 = new JButton("Add to Stock");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Vehicle v=new Vehicle();
				v.setModelName(t1.getText());
				v.setType(t2.getText());
				v.setModelYear(Integer.parseInt(t3.getText()));
				v.setEngineCapacity(Integer.parseInt(t4.getText()));
				v.setAverageMilage(Integer.parseInt(t5.getText()));
				v.setQuantity(Integer.parseInt(t6.getText()));
				v.setWarrenty(Integer.parseInt(t7.getText()));
				v.setOnRoadPrice(Double.parseDouble(t9.getText()));
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/showroom","root","");
					String qry="insert into vehicle(modelName,type,ModelYear,engineCapacity,averageMilage,quantity,warrenty,onRoadPrice) values(?,?,?,?,?,?,?,?)";
					PreparedStatement pState=con.prepareStatement(qry);
					pState.setString(1, v.getModelName());pState.setString(2, v.getType());
					pState.setInt(3, v.getModelYear());pState.setInt(4, v.getEngineCapacity());
					pState.setInt(5, v.getAverageMilage());pState.setInt(6, v.getQuantity());
					pState.setInt(7, v.getWarrenty());
					pState.setDouble(8, v.getOnRoadPrice());
					int status=pState.executeUpdate();
					if(status!=0)
					{
						JOptionPane.showMessageDialog(AddToStock.this, "Vehicle added to stock");
						t1.setText("");t2.setText("");t3.setText("");t4.setText("");t5.setText("");
						t6.setText("");t7.setText("");t9.setText("");
					}
					else
					{
						throw new VehicleException();
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch(VehicleException x)
				{
					JOptionPane.showMessageDialog(AddToStock.this, x);
				}
			}
		});
		b1.setBounds(209, 361, 122, 23);
		contentPane.add(b1);
		
		JButton b2 = new JButton("Cancel");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				t1.setText("");t2.setText("");t3.setText("");t4.setText("");t5.setText("");
				t6.setText("");t7.setText("");t9.setText("");
			}
		});
		b2.setBounds(414, 361, 89, 23);
		contentPane.add(b2);
		
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SwingUtilities.updateComponentTreeUI(contentPane);
	}
}
