package show.middle;

public class VehicleException extends Exception
{
	public VehicleException(){super("Vehicle Not Found");}
	public VehicleException(String k){super("Vehicle "+k);}
}
