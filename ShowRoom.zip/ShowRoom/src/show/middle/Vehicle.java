package show.middle;

public class Vehicle 
{
	private String modelName,type;
	private int modelYear,engineCapacity,averageMilage,quantity,warrenty;
	//private long chaseNumber;
	private Double onRoadPrice;
	public Vehicle(){}
	public Vehicle(String a,String b,int c,int d,int e,int f,int g,double i)
	{
		modelName=a;type=b;modelYear=c;engineCapacity=d;averageMilage=e;
		quantity=f;warrenty=g;//chaseNumber=h;
		onRoadPrice=i;
	}
	public String toString()
	{
		String k="";
		k+=modelName+"\n"+type+"\n"+modelYear+"\n"+engineCapacity+"\n"+averageMilage+"\n"+quantity+"\n"+warrenty+"\n"+onRoadPrice+"\n";
		return k;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getModelYear() {
		return modelYear;
	}
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}
	public int getEngineCapacity() {
		return engineCapacity;
	}
	public void setEngineCapacity(int engineCapacity) {
		this.engineCapacity = engineCapacity;
	}
	public int getAverageMilage() {
		return averageMilage;
	}
	public void setAverageMilage(int averageMilage) {
		this.averageMilage = averageMilage;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getWarrenty() {
		return warrenty;
	}
	public void setWarrenty(int warrenty) {
		this.warrenty = warrenty;
	}
	public Double getOnRoadPrice() {
		return onRoadPrice;
	}
	public void setOnRoadPrice(Double onRoadPrice) {
		this.onRoadPrice = onRoadPrice;
	}
}
