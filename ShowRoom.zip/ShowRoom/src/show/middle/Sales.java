package show.middle;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Sales 
{
	private LocalDate date;
	private String modelName,consumerName,address,paymentMode;
	private Long mobileNumber;
	private Integer paid,invoiceNumber;
	private Double onRoadPrice;
	public Sales(){}
	public Sales(String a,String b,String c,String d,String e,long f,int g,int h,double i)
	{
		date=LocalDate.parse(a,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		modelName=b;consumerName=c;address=d;paymentMode=e;mobileNumber=f;
		paid=g;invoiceNumber=h;onRoadPrice=i;
	}
	public Double getOnRoadPrice() {
		return onRoadPrice;
	}
	public void setOnRoadPrice(Double onRoadPrice) {
		this.onRoadPrice = onRoadPrice;
	}
	public Integer getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(Integer invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getDate() {
		return date.toString();
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public void setDate(String date) {
		this.date=LocalDate.parse(date,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Integer getPaid() {
		return paid;
	}
	public void setPaid(Integer paid) {
		this.paid = paid;
	}
	public String toString()
	{
		String y="";
		y+=date+"\n"+modelName+"\n"+consumerName+"\n"+address+"\n"+paymentMode+"\n"+mobileNumber+"\n"+paid+"\n"+invoiceNumber+"\n";
		return y;
	}
}
