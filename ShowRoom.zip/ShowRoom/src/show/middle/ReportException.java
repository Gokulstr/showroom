package show.middle;

public class ReportException extends Exception
{
	public ReportException(){super("Repoprt Not Found");}
}
